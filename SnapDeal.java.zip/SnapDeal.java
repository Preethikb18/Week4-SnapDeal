package week4.day2;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;
import jdk.javadoc.internal.doclets.toolkit.util.DocFinder.Output;

public class SnapDeal {

	private static final OutputType<File> Outputfile = null;

	public static void main(String[] args) throws IOException, InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.snapdeal.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		Actions builder = new Actions(driver);
	   // WebElement mens = driver.findElement(By.xpath("////span[@class='catText']"));
	    WebElement mens = driver.findElement(By.className("catText"));
	    builder.moveToElement(mens).perform();
        driver.findElement(By.xpath("//span[text()='Sports Shoes']")).click();
        String noOfShoes = driver.findElement(By.xpath("//span[@class='category-name category-count']")).getText();
        System.out.println(noOfShoes);
        driver.findElement(By.xpath("//div[text()='Training Shoes']")).click();
        driver.findElement(By.xpath("//div[@class='sort-selected']")).click();
		driver.findElement(By.xpath("//ul[@class='sort-value']//li[2]")).click();
		//Select the price range (900-1200)
		WebElement from = driver.findElement(By.xpath("(//div[@class='price-text-box']//input)[1]"));
	    from.clear();
	    from.sendKeys("900");
	    WebElement to = driver.findElement(By.xpath("(//div[@class='price-text-box']//input)[2]"));
		to.clear();
		to.sendKeys("1200");
		driver.findElement(By.xpath("//div[@class='price-go-arrow btn btn-line btn-theme-secondary']")).click();
        //Filter with color Navy & verify the all applied filters
	     Thread.sleep(3000);
		driver.findElement(By.xpath("//button[text()='View More ']")).click();
		driver.findElement(By.xpath("//label[@for='Color_s-Navy']/span")).click();
		//driver.findElement(By.xpath("//label[@for='Color_s-Navy']//..")).click();
		WebElement verfyFilter = driver.findElement(By.xpath("(//div[@class='filters'])[1]"));
		String filter = verfyFilter.getText();
		System.out.println("Filters Applied : "+filter);
		driver.findElement(By.xpath("//div[contains(text(),'Quick View')]"));
		driver.findElement(By.xpath("//div[@class='sidebaroverlay']"));
		File snapOfShoe = driver.getScreenshotAs(OutputType.FILE);
		File destination = new File("./out.png");
		FileUtils.copyFile(snapOfShoe, destination);
		driver.close();
		
		
		
		
		
		
		
	}
	
}
